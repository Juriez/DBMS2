from apriory import Apriory


file_path = "C:/Users/Hasibul Hossain/Desktop/Asif Bhai git/DBMS-II/Apriory/item_set.csv"

min_support=int (input("Min Support: "))

object_apriory = Apriory(min_support)

item_count_dict, frequent_item_set = object_apriory.apriory_fit(file_path)

for key, value in frequent_item_set.items():
    print('frequent {}-term set:'.format(key))
    print('-'*20)
    for itemset in value:
        print(list(itemset))
    print()


