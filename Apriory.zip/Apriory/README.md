# apriori-agorithm-python

[![Build Status](https://github.com/tommyod/Efficient-Apriori/workflows/Python%20CI/badge.svg?branch=master)

An Effectively Python Implementation of Apriori Algorithm for Finding Frequent sets and Association Rules

# Reference

> _Agrawal R, Srikant R. Fast algorithms for mining association rules[C]//Proc. 20th int. conf. very large data bases, VLDB. 1994, 1215: 487-499._

# License

No liscense. Open for all.
